﻿namespace Movies.Contracts.Responses;

public class MoviesResponse : PagedResponse<MovieResponse>
{
    
}
